import random
from tortoise.exceptions import IntegrityError , DoesNotExist
from tortoise import Tortoise, fields
from tortoise.models import Model



class City(Model):
    id = fields.IntField(pk=True)
    city = fields.CharField(max_length=255, unique=True)
    people = fields.JSONField(default=list)     
    reserve = fields.BooleanField(default=False)

    def __str__(self):
        return f'{self.city}: {self.people}'

class User(Model):
    user_id = fields.IntField(pk=True)
    name = fields.TextField()

class Admin(Model):
    user_id = fields.IntField(pk=True)


class SQLiteDatabase:
    def __init__(self, db_url='sqlite://db.sqlite3'):
        self.db_url = db_url

    async def connect(self):
        try:
            await Tortoise.init(
                db_url=self.db_url,
                modules={'models': ['database.databaseJ' , 'database.databaseJ' , 'database.databaseJ']}
            )
            await Tortoise.generate_schemas()
        except Exception as e:
            print(f"Error connecting to SQLite: {e}")
    
    async def add_admin(self, user_id):
        """
        Add a new user to the database.
        """
        try:
            user, created = await Admin.get_or_create(user_id=user_id)
            if not created:
                pass
            else:
                print(f"User {user_id} added successfully.")
        except Exception as e:
            print(f"Error adding user {user_id}: {e}")

    async def get_user_count(self):
            try:
                user_count = await User.all().count()
                return user_count
            except Exception as e:
                return 0

    async def add_user(self, user_id, name):
        """
        Add a new user to the database.
        """
        try:
            user, created = await User.get_or_create(user_id=user_id, defaults={'name': name})
            if not created:
                pass
            else:
                print(f"User {name} added successfully.")
        except Exception as e:
            print(f"Error adding user {user_id}: {e}")

    async def add_data(self, data):
        """
        Add or update city data in the database.

        Args:
            data (dict): A dictionary where keys are city names and values are lists of dictionaries.
                        Each dictionary in the list contains 'name' and 'username'.
        """
        if not isinstance(data, dict):
            raise ValueError("Data must be a dictionary.")

        for city_name, people_list in data.items():
            try:
                city_obj, created = await City.get_or_create(city=city_name)

                if city_obj.people is None:
                    city_obj.people = []

                city_obj.people.clear()

                for person in people_list:
                    person_info = {
                        "name": person.get("name", ""),  
                        "username": person.get("username", "")  
                    }
                    city_obj.people.append(person_info)

                await city_obj.save()
            except IntegrityError as e:
                print(f"Integrity error occurred for city {city_name}: {e}")
            except ValueError as e:
                print(f"Invalid data for city {city_name}: {e}")
            except Exception as e:
                print(f"An unexpected error occurred for city {city_name}: {e}")

    async def update_city(self, city_name, username=None, reserve=None):
        """
        Update `username` and/or `reserve` for a specific city.
        """
        try:
            city_obj = await City.get(city=city_name)
            if username is not None:
                city_obj.username = username
            if reserve is not None:
                city_obj.reserve = reserve
            await city_obj.save()
        except City.DoesNotExist:
            print(f"City {city_name} does not exist.")
        except Exception as e:
            print(f"Error updating city {city_name}: {e}")

    async def get_all_keys(self):
        """Get all city names (keys) from the database."""
        try:
            cities = await City.all()  
            return [city.city for city in cities]  
        except Exception as e:
            return None  

    async def get_data(self, key):
        try:
            city_obj = await City.get(city=key)
            return city_obj.people if city_obj else None
        except Exception as e:
            print(f"Error retrieving data for city {key}: {e}")
            return None

    async def delete_data(self, key, sub_key):
        try:
            city_obj = await City.get(city=key)
            if city_obj and sub_key in city_obj.people:
                city_obj.people.remove(sub_key)
                await city_obj.save()
            else:
                raise ValueError(f"Person not found in city.")
        except ValueError as e:
            print(f"Error: {e}")
        except Exception as e:
            print(f"Unexpected error: {e}")

    async def delete_person_by_name(self, name):
        """
        Delete a person from the `people` column in all cities by their name.

        Args:
            name (str): The name of the person to be removed.
        """
        try:
            cities = await City.all()

            for city in cities:
                updated_people = [
                    person for person in city.people if person.get("name") != name
                ]
                if len(updated_people) != len(city.people):
                    city.people = updated_people
                    await city.save()
                    print(f"Person '{name}' removed from city '{city.city}'.")
        except Exception as e:
            print(f"Error removing person '{name}': {e}")

    async def get_random_admin(self):
        """
        Get a random user_id from the Admin model.

        Returns:
            int: A random user_id or None if no admins exist.
        """
        try:
            admins = await Admin.all()
            
            if not admins:
                return None
            
            random_admin = random.choice(admins)
            return random_admin.user_id
        except DoesNotExist:
            print("No admin records found.")
            return None
        except Exception as e:
            print(f"Error retrieving random admin: {e}")
            return None

    async def close(self):
        try:
            await Tortoise.close_connections()
        except Exception as e:
            print(f"Error closing database connection: {e}")

    async def __aenter__(self):
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()
