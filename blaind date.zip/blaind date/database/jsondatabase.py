import json
import os

class JSONDatabase:
    def __init__(self, file_name='database.json', default_key='default'):
        self.file_name = file_name
        self.default_key = default_key  
        self.data = self._load_data()
        if self.default_key not in self.data:
            self.data[self.default_key] = {}
            self._save_data()

    def _load_data(self):
        """Load data from the JSON file."""
        if os.path.exists(self.file_name):
            with open(self.file_name, 'r', encoding='utf-8') as file:
                return json.load(file)
        return {}

    def _save_data(self):
        """Save data to the JSON file."""
        with open(self.file_name, 'w', encoding='utf-8') as file:
            json.dump(self.data, file, ensure_ascii=False, indent=4)

    def add_data(self, reserve_key=None, data=None):
        """
        Add data to the database under a specified key, or the default key if not provided.
        
        Args:
            reserve_key (str): The key under which the data will be stored. Defaults to the default key.
            data (dict): The data to be saved.
        """
        if not data:
            print("No data provided to save.")
            return

        target_key = reserve_key if reserve_key else self.default_key

        if not isinstance(self.data.get(target_key, None), dict):
            self.data[target_key] = {}

        data_id = len(self.data[target_key]) + 1  
        self.data[target_key][data_id] = data

        self._save_data()
        return data_id

    def get_data(self, reserve_key=None, data_id=None):
        """
        Retrieve data from the database by its key or a specific ID within a key.
        
        Args:
            reserve_key (str): The key to retrieve data for. Defaults to the default key.
            data_id (str|int): The specific ID within the key to retrieve data for.
        
        Returns:
            dict|None: The data or None if the key or ID does not exist.
        """
        target_key = reserve_key if reserve_key else self.default_key
        
        if target_key not in self.data:
            print(f"Key '{target_key}' does not exist in the database.")
            return None

        if data_id is not None:
            data_id = str(data_id)
            return self.data[target_key].get(data_id, None)
        
        return self.data.get(target_key, None)


    def update_data(self, reserve_key, data):
        """
        Update data in the database.
        
        Args:
            reserve_key (str): The key of the data to update.
            data (dict): The new data to save.
        """
        if reserve_key in self.data:
            self.data[reserve_key] = data
            self._save_data()
            print(f"Data with key '{reserve_key}' has been updated.")
        else:
            print(f"Data with key '{reserve_key}' does not exist.")

    def delete_data(self, reserve_key):
        """
        Delete data from the database by its key.
        
        Args:
            reserve_key (str): The key of the data to delete.
        """
        if reserve_key in self.data:
            del self.data[reserve_key]
            self._save_data()
            print(f"Data with key '{reserve_key}' has been deleted.")
        else:
            print(f"Data with key '{reserve_key}' does not exist.")
