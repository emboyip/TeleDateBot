from pyrogram.types import ReplyKeyboardMarkup

admin = ReplyKeyboardMarkup(
    [
        ["لیست✅"],
        ["امار بات📱"],
        ["اضافه کردن ادمین💶"]
    ],resize_keyboard=True
)

