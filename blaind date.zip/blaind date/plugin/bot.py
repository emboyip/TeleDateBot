from pyrogram import Client, filters
from pyromod import listen
from pyromod.exceptions.listener_timeout import ListenerTimeout
from pyrogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from button.keyboard import admin
from setting.var import admins, user_poket, make_btn, create_inline_keyboard , extract_data , remove_bracketed_data ,chanel_id , add_green_tick
from database.databaseJ import SQLiteDatabase
from database.jsondatabase import JSONDatabase
from client import TelegramClientManager


json = JSONDatabase()
city_dict = {}
app = TelegramClientManager(api_id='' , api_hash='')
msg_id = None

@Client.on_message(filters.user(admins), group=2)
async def admin_panel(c: Client, m: Message):
    if m.text == "/admin":
        await m.reply_text("سلام به پنل ادمین خوش آمدید 🦋", reply_markup=admin)
    elif m.text == "لیست✅":
        await m.reply_text("لطفاً لیست را ارسال کنید.")
        user_poket.setdefault(m.from_user.id, {})["step"] = "get_list"
    elif m.text == "امار بات📱":
        async with SQLiteDatabase() as dbr:
            user_list = await dbr.get_user_count()
        await m.reply_text(f"📊امار تعداد کاربران بات📊\n\n تعداد:{user_list}")
    elif m.text == "اضافه کردن ادمین💶":
        await m.reply_text("لطقا ایدی عددی ادمین را ارسال کنید")
        user_poket.setdefault(m.from_user.id , {})["step"] = "get_admin"

@Client.on_message(group=1)
async def start_handler(c: Client, m: Message):
    if m.text == "/start":
        async with SQLiteDatabase() as dbr:
            city_list = await dbr.get_all_keys()
            await dbr.add_user(user_id=m.from_user.id , name=m.from_user.first_name)
        if city_list:
            btn_list = make_btn(city_list)
            await m.reply_text(
                "لطفاً شهر خود را با کلیک بر روی دکمه انتخاب کنید 🔥", 
                reply_markup=btn_list
            )


@Client.on_message(group=10)
async def step_handler(c: Client, m: Message):
    global msg_id
    step = user_poket.get(m.from_user.id, {}).get("step")
    if step == "get_list":
        if m.text == "لیست✅":
            return

        try:
            city_dict = extract_data(m.text)
            async with SQLiteDatabase() as dbr:
                await dbr.add_data(city_dict)
            await m.reply_text("لیست با موفقیت ذخیره شد ✅")
            clean_text =  remove_bracketed_data(m.text)
            ids = await c.send_message(chat_id=chanel_id , text=clean_text)
            msg_id = ids.id 
            user_poket.setdefault(m.from_user.id , {})["step"] = "0"
        except Exception as e:
            await m.reply_text(f"خطا در ذخیره لیست: {e}")
            user_poket.setdefault(m.from_user.id , {})["step"] = "0"
    elif step == "get_admin":
        if m.text == "اضافه کردن ادمین💶":
            return
        try:
            async with SQLiteDatabase() as dbr:
                await dbr.add_admin(user_id=int(m.text))
                await m.reply_text("ادمین با موفقیت اضافه شد")
            user_poket.setdefault(m.from_user.id , {})["step"] = "0"
        except:
            await m.reply_text("error")
            user_poket.setdefault(m.from_user.id , {})["step"] = "0"


@Client.on_callback_query()
async def callback_handler(c: Client, ca: CallbackQuery):
    data = ca.data
    global city_dict
    
    if data.startswith("city_select"):
        city = data.split("|")[1]
        confirm_keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton(text="تایید✅", callback_data=f"config|{city}")],
            [InlineKeyboardButton(text="کنسل", callback_data="cancel")]
        ])
        await ca.edit_message_text(
            "قیمت دیت برای 180 هزار تومان می‌باشد", 
            reply_markup=confirm_keyboard
        )
    
    elif data == "cancel":
        await ca.edit_message_text("رزرو شما کنسل شد ✅")
    
    elif data.startswith("config"):
        city = data.split("|")[1]
        city_dict.setdefault(ca.from_user.id, {})["city"] = city
        
        async with SQLiteDatabase() as dbr:
            city_data = await dbr.get_data(key=city)
        
        await ca.edit_message_text(
            text="لطفاً فرد مورد نظر را انتخاب کنید", 
            reply_markup=create_inline_keyboard(city_data)
        )
    
    elif data.startswith("btn_"):
        button_text = next(
            (button.text for row in ca.message.reply_markup.inline_keyboard for button in row if button.callback_data == ca.data),
            None
        )
        try:
            await c.delete_messages(chat_id=ca.message.chat.id, message_ids=ca.message.id)
            text = (
                "🤖 لطفاً مبلغ 180 هزار تومان به شماره کارت زیر واریز کنید 🤖\n\n"
                "💳 621986198092092 💳\n\n"
                "⚠️ توجه کنید شما فقط دو دقیقه برای پرداخت وقت دارید، در غیر این صورت رزرو شما از بین می‌رود ⚠️"
            )
            msg = await c.ask(chat_id=ca.message.chat.id, text=text, timeout=120)
            if msg.photo:
                text = "🎉پرداختی جدید دارید🎉"
                confim_ = InlineKeyboardMarkup(
                    [
                        [InlineKeyboardButton(text="تایید✅", callback_data=f"taiid|{ca.from_user.id}|{button_text}")],
                        [InlineKeyboardButton(text="کنسل❌", callback_data=f"cansol|{ca.from_user.id}")]
                    ]
                )
                await c.send_photo(chat_id=admins[0], caption=text, photo=msg.photo.file_id, reply_markup=confim_)
                await ca.message.reply_text(text="فیش شما ارسال شد. به محض تایید، لینک گپ برایتان ارسال خواهد شد 🎉")

        except ListenerTimeout:
            await c.send_message(chat_id=ca.message.chat.id, text="🔥 تایم پرداخت شما به اتمام رسید 🔥")
    
    elif data.startswith("taiid"):
        parts = data.split("|")
        user_id = parts[1]
        girl_name = parts[2]

        if int(user_id) not in city_dict:
            await ca.answer("اطلاعات کاربر یافت نشد.", show_alert=True)
            return

        city_info = city_dict[int(user_id)]["city"]

        async with SQLiteDatabase() as dbr:
            dbr_city = await dbr.get_data(city_info)
            await dbr.delete_person_by_name(girl_name)
            admin_id = await dbr.get_random_admin()

        girl_info = next((i for i in dbr_city if i["name"] == girl_name), None)
        if not girl_info:
            await ca.answer("اطلاعات دختر مورد نظر یافت نشد.", show_alert=True)
            return

        json_data = {
            "name": girl_name,
            "username": girl_info["username"],
            "user_id": user_id
        }
        json.add_data(data=json_data)
        await app.start()
        link = await app.create_group(group_name="بلایند دیت")
        await app.stop()
        await c.send_message(chat_id=admin_id , text=f"ادمین عزیز لطفا جوین بشید\n\n {link}")
        await c.send_message(chat_id=user_id , text=f"کاربر گرامی جوین بشید\n\n {link}")
        await c.send_message(chat_id=girl_info["username"] , text=f"کاربر عزیز لطفا جوین بشید\n\n {link}")
        await ca.edit_message_caption(f"با موفقیت انجام شد\n\n نام دختر:{girl_name}")

    elif data.startswith("cansol"):
        user_ids = data.split("|")[1]
        await c.send_message(chat_id=user_ids , text="کاربر گرامی فیش شما رد شد😭")