from pyrogram import Client

class TelegramClientManager:
    def __init__(self, api_id, api_hash, session_name="Account"):
        """
        """
        self.api_id = api_id
        self.api_hash = api_hash
        self.session_name = session_name
        self.client = Client(self.session_name, api_id=self.api_id, api_hash=self.api_hash)

    async def start(self):
        await self.client.start()

    async def stop(self):
        await self.client.stop()

    async def send_message(self, chat_id, text):
        """
        """
        try:
            await self.client.send_message(chat_id, text)
            print(f"Message sent to {chat_id}: {text}")
        except Exception as e:
            print(f"Error sending message: {e}")

    async def create_group(self, group_name):
        """
        """
        try:
            group = await self.client.create_group(
                title=group_name,
                users="dsksknsknsbot"
            )
            link = await self.client.create_chat_invite_link(chat_id=group.id)
            return link.invite_link
        except Exception as e:
            print(f"Error creating group: {e}")

    async def get_user_info(self, user_id):
        """
        """
        try:
            user = await self.client.get_users(user_id)
            print(f"User Info: {user}")
            return user
        except Exception as e:
            print(f"Error getting user info: {e}")

    async def send_photo(self, chat_id, photo_path):
        """
        """
        try:
            await self.client.send_photo(chat_id, photo_path)
            print(f"Photo sent to {chat_id}")
        except Exception as e:
            print(f"Error sending photo: {e}")

    async def get_messages(self, chat_id, limit=10):
        """
        """
        try:
            messages = await self.client.get_chat_history(chat_id, limit=limit)
            for message in messages:
                print(f"Message from {message.from_user.id}: {message.text}")
            return messages
        except Exception as e:
            print(f"Error retrieving messages: {e}")
            return []