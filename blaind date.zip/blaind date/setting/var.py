from collections import defaultdict
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup
import re

def Tree():
    return defaultdict(Tree)



chanel_id = "Hooddp"
admins = [111]
user_poket = Tree()
def make_btn(buttons_list):
    buttons = []
    for i in range(0, len(buttons_list), 2): 
        row = []
        for j in range(2):
            if i + j < len(buttons_list):
                row.append(InlineKeyboardButton(buttons_list[i + j], callback_data=f"city_select|{buttons_list[i + j]}"))
        buttons.append(row)
    return InlineKeyboardMarkup(buttons)

def create_inline_keyboard(buttons_list):
    """
    Creates an inline keyboard from a given list of button texts.

    Args:
        buttons_list (list of str): List of button texts.

    Returns:
        InlineKeyboardMarkup: The generated inline keyboard.
    """
    keyboard = []
    for i, button_text in enumerate(buttons_list):
        callback_data = f"btn_{i}"
        keyboard.append([InlineKeyboardButton(text=button_text["name"], callback_data=callback_data)])
    keyboard.append([InlineKeyboardButton(text="برگشت📱" , callback_data="back")])
    return InlineKeyboardMarkup(keyboard)

def extract_data(text):
    """
    Extracts city-specific data from the given text.
    
    Args:
        text (str): The input text containing city data.
        
    Returns:
        dict: A dictionary where keys are city names and values are lists of dictionaries
              with 'name' and 'username'.
    """
    data = defaultdict(list)
    
    sections = re.split(r'#(?=\w+)', text)
    for section in sections[1:]:
        lines = section.strip().split('\n')
        city = lines[0].strip()  
        for line in lines[1:]:
            match = re.match(r"(.*?)\s*\[([^\]]*)\]$", line.strip())
            if match:
                name_info = match.group(1).strip()
                username = match.group(2).strip() if match.group(2) else ''
                data[city].append({"name": name_info, "username": username})
    
    return dict(data)

def remove_bracketed_data(text):
    cleaned_text = re.sub(r'\[.*?\]', '', text)
    
    cleaned_text = re.sub(r'\n+', '\n', cleaned_text).strip()
    
    return cleaned_text

def add_green_tick(text, name):
    updated_text = re.sub(rf'(\b{name}\b)', r'\1 ✅', text)
    
    return updated_text