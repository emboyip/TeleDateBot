from pyrogram import Client
from pyromod import listen

plugins = dict(root='plugin')

app = Client(
    name='emboy',
    api_id=1111,
    api_hash='',
    bot_token="",
    plugins=plugins
)


app.run()